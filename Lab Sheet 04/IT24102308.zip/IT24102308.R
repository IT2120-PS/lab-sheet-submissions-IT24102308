setwd("C:\\Users\\it24102308\\Desktop\\IT24102308")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
str(branch_data)
boxplot(branch_data$Sales_X1, main = "Boxplot for Sales", ylab = "Sales", outline = TRUE, horizontal = FALSE)

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

get_outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  print(paste("Lower Bound =", lb))
  print(paste("Upper Bound =", ub))
  outliers <- sort(z[z < lb | z > ub])
  if (length(outliers) > 0) {
    print(paste("Outliers:", paste(outliers, collapse = " ")))
  } else {
    print("Outliers: None")
  }
}
get_outliers(branch_data$Years_X3)