setwd("C:/Users/Samsung/OneDrive/Desktop/Lab 05")

# Q1
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=",")

# Q2
hist(Delivery_Times$Delivery_Time, breaks=seq(20, 70, length=10), right=TRUE, main="Histogram for Delivery Times", xlab="Delivery Time", ylab="Frequency")

# Q4
breaks <- seq(20, 70, length=10)
cum_freq <- cumsum(table(cut(Delivery_Times$Delivery_Time, breaks=breaks, right=TRUE)))
plot(seq(20, 70, length=9), cum_freq, type="o", main="Ogive for Delivery Times", xlab="Delivery Time", ylab="Cumulative Frequency")